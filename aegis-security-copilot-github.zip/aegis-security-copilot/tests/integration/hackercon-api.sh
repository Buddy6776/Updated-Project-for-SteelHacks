#!/usr/bin/env bash
set -euo pipefail

TEST_PORT="${AEGIS_TEST_PORT:-3012}"
TEST_ORIGIN="http://127.0.0.1:${TEST_PORT}"
TEST_TMP="$(mktemp -d "${TMPDIR:-/tmp}/aegis-hackercon.XXXXXX")"
TEST_LOG="${TEST_TMP}/worker.log"
COOKIE_ONE="${TEST_TMP}/user-one.cookies"
COOKIE_TWO="${TEST_TMP}/user-two.cookies"
HEADERS_ONE="${TEST_TMP}/signup-one.headers"
BODY="${TEST_TMP}/body.json"

cleanup() {
  if [[ -n "${WORKER_PID:-}" ]]; then
    kill "${WORKER_PID}" 2>/dev/null || true
    wait "${WORKER_PID}" 2>/dev/null || true
  fi
}
trap cleanup EXIT

status_for() {
  curl -sS -o "${BODY}" -w '%{http_code}' "$@"
}

expect_status() {
  local expected="$1"
  shift
  local actual
  actual="$(status_for "$@")"
  if [[ "${actual}" != "${expected}" ]]; then
    printf 'Expected HTTP %s, received %s\n' "${expected}" "${actual}" >&2
    sed -n '1,80p' "${BODY}" >&2
    exit 1
  fi
}

json_field() {
  python3 -c 'import json,sys; value=json.load(open(sys.argv[1])); print(eval(sys.argv[2], {"value": value}))' "$1" "$2"
}

pnpm exec wrangler d1 migrations apply DB --local --config wrangler.pi.jsonc --persist-to "${TEST_TMP}" >/dev/null
pnpm exec wrangler dev --local --config wrangler.pi.jsonc --persist-to "${TEST_TMP}" --ip 127.0.0.1 --port "${TEST_PORT}" >"${TEST_LOG}" 2>&1 &
WORKER_PID=$!

for _ in {1..60}; do
  if curl -fsS "${TEST_ORIGIN}/api/health" >/dev/null 2>&1; then
    break
  fi
  sleep 0.2
done
curl -fsS "${TEST_ORIGIN}/api/health" >/dev/null

# Authentication boundary and safe target validation.
expect_status 401 "${TEST_ORIGIN}/api/history"
expect_status 401 "${TEST_ORIGIN}/api/scans/not-a-scan"
expect_status 400 -X POST -H 'content-type: application/json' --data '{"url":"https://127.0.0.1"}' "${TEST_ORIGIN}/api/public-scans/stream"

# Local account one. Capture and verify hardened cookie properties.
expect_status 201 -D "${HEADERS_ONE}" -c "${COOKIE_ONE}" -X POST -H 'content-type: application/json' --data '{"email":"hackercon-one@example.net","displayName":"<script>alert(1)</script>","password":"Conference-Test-Password-1!","acceptTerms":true}' "${TEST_ORIGIN}/api/auth/signup"
grep -qi 'set-cookie: aegis_session=.*HttpOnly.*SameSite=Lax' "${HEADERS_ONE}"
expect_status 200 -b "${COOKIE_ONE}" "${TEST_ORIGIN}/dashboard"
expect_status 404 -b "${COOKIE_ONE}" "${TEST_ORIGIN}/api/scans/not-a-scan"
if grep -q '<script>alert(1)</script>' "${BODY}"; then
  printf 'Unescaped display name reached dashboard HTML.\n' >&2
  exit 1
fi

# Duplicate registration is idempotent for one workspace.
expect_status 201 -b "${COOKIE_ONE}" -X POST -H 'content-type: application/json' --data '{"url":"https://example.com"}' "${TEST_ORIGIN}/api/websites"
SITE_ONE="$(json_field "${BODY}" 'value["website"]["id"]')"
expect_status 200 -b "${COOKIE_ONE}" -X POST -H 'content-type: application/json' --data '{"url":"https://example.com"}' "${TEST_ORIGIN}/api/websites"
SITE_ONE_AGAIN="$(json_field "${BODY}" 'value["website"]["id"]')"
[[ "${SITE_ONE}" == "${SITE_ONE_AGAIN}" ]]

# Ownership state blocks saved scanning and active authorization.
expect_status 403 -b "${COOKIE_ONE}" -X POST -H 'content-type: application/json' --data "{\"websiteId\":\"${SITE_ONE}\"}" "${TEST_ORIGIN}/api/scans/run"
expect_status 403 -b "${COOKIE_ONE}" -X POST -H 'content-type: application/json' --data "{\"websiteId\":\"${SITE_ONE}\",\"acknowledgement\":true}" "${TEST_ORIGIN}/api/websites/authorize"

# A second workspace cannot enumerate or operate on the first workspace's asset.
expect_status 201 -c "${COOKIE_TWO}" -X POST -H 'content-type: application/json' --data '{"email":"hackercon-two@example.net","displayName":"Second Workspace","password":"Conference-Test-Password-2!","acceptTerms":true}' "${TEST_ORIGIN}/api/auth/signup"
expect_status 200 -b "${COOKIE_TWO}" "${TEST_ORIGIN}/api/websites"
if grep -q "${SITE_ONE}" "${BODY}"; then
  printf 'Workspace isolation failed: another user could enumerate the asset.\n' >&2
  exit 1
fi
expect_status 404 -b "${COOKIE_TWO}" -X POST -H 'content-type: application/json' --data "{\"websiteId\":\"${SITE_ONE}\",\"method\":\"dns\"}" "${TEST_ORIGIN}/api/websites/verify"
expect_status 404 -b "${COOKIE_TWO}" -X POST -H 'content-type: application/json' --data "{\"websiteId\":\"${SITE_ONE}\",\"acknowledgement\":true}" "${TEST_ORIGIN}/api/websites/authorize"

# Account scan cooldown and password lockout are enforced.
expect_status 404 -b "${COOKIE_TWO}" -X POST -H 'content-type: application/json' --data "{\"websiteId\":\"${SITE_ONE}\"}" "${TEST_ORIGIN}/api/scans/run"
expect_status 429 -b "${COOKIE_TWO}" -X POST -H 'content-type: application/json' --data "{\"websiteId\":\"${SITE_ONE}\"}" "${TEST_ORIGIN}/api/scans/run"
for _ in {1..5}; do
  expect_status 401 -X POST -H 'content-type: application/json' --data '{"email":"hackercon-one@example.net","password":"Definitely-Wrong-Password"}' "${TEST_ORIGIN}/api/auth/login"
done
expect_status 429 -X POST -H 'content-type: application/json' --data '{"email":"hackercon-one@example.net","password":"Conference-Test-Password-1!"}' "${TEST_ORIGIN}/api/auth/login"

printf 'HackerCon API integration checks passed. Temporary evidence: %s\n' "${TEST_TMP}"
