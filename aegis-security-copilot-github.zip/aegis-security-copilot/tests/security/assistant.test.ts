import assert from 'node:assert/strict';
import test from 'node:test';
import { generateAssistantReply,type AssistantContext } from '../../app/aegis-assistant.ts';

const context:AssistantContext={hostname:'business.example.com',scanId:'scan-123',score:72,coverage:55,findings:[{id:'FIND-004',type:'missing_hsts',title:'HSTS protection is missing',severity:'medium',confidence:'high',evidence:'Strict-Transport-Security was not observed.',businessImpact:'Visitors have less downgrade protection.',technicalExplanation:'The response omitted the HSTS header.',remediation:'Enable HSTS after validating HTTPS.'}]};
test('grounds priority answers in current finding IDs',()=>{const answer=generateAssistantReply('What should I fix first?',context);assert.match(answer,/FIND-004/);assert.match(answer,/Enable HSTS/)});
test('cites current evidence for technical questions',()=>{const answer=generateAssistantReply('Show me the evidence for FIND-004',context);assert.match(answer,/Strict-Transport-Security was not observed/);assert.match(answer,/Observed/);assert.match(answer,/Inferred impact/);assert.match(answer,/Recommended/)});
test('does not claim vulnerabilities absent from current evidence',()=>{const answer=generateAssistantReply('Do I have SQL injection?',context);assert.match(answer,/cannot confirm/i);assert.match(answer,/scan-123/)});
test('does not infer HSTS when matching evidence is absent',()=>{const answer=generateAssistantReply('Is HSTS missing?',{...context,findings:[]});assert.match(answer,/not confirmed/i)});
