import assert from 'node:assert/strict';
import test from 'node:test';
import { escapeReportHtml } from '../../app/security/report.ts';
test('escapes untrusted target and finding text for HTML reports',()=>{assert.equal(escapeReportHtml(`<img src=x onerror="alert('x')"> & done`),'&lt;img src=x onerror=&quot;alert(&#39;x&#39;)&quot;&gt; &amp; done')});
