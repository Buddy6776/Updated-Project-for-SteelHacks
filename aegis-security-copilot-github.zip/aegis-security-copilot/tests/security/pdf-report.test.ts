import assert from 'node:assert/strict';
import test from 'node:test';
import { createSecurityReportPdf } from '../../app/security/report-downloads.ts';

test('generates a real PDF from bounded report data',async()=>{const bytes=await createSecurityReportPdf({audience:'Technical',title:'Aegis Test Report',target:'safe.example.com',scanId:'scan-test',generatedAt:'2026-08-28T00:00:00Z',score:80,coverage:55,provenance:'live',summary:'Evidence-backed test report.',scope:'Passive public review only.',checks:[{label:'Headers',status:'Completed'}],findings:[{id:'FIND-001',title:'Test finding',severity:'low',confidence:'high',source:'test',evidence:'Observed test evidence.',businessImpact:'Test impact.',remediation:'Test remediation.',verificationGuidance:'Rerun the check.',affectedResource:'https://safe.example.com/'}]});assert.equal(new TextDecoder().decode(bytes.slice(0,5)),'%PDF-');assert.ok(bytes.byteLength>1500)});
