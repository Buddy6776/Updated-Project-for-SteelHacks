# Aegis Security Copilot

![Aegis Security Copilot](public/og.png)

Aegis is a cybersecurity copilot for small businesses. Visitors can review a website's public security signals, while verified owners can register domains, run authorized assessments, prioritize findings, follow remediation work, verify fixes, and ask questions about their actual security data in plain language.

> **Project status:** HackerCon-ready defensive demo and functional MVP. The public review now streams real check state, preserves target-specific raw evidence, labels provenance, and refuses to infer findings from unavailable evidence. Aegis-owned accounts, ownership verification, scan history, finding lifecycle, comparison, bounded fix verification, audit events, and a separate clearly labeled `/demo` walkthrough are implemented. Active scanners require the isolated runner and remain disabled by default.

## Why Aegis

Security tools are powerful, but their output is often difficult for a business owner to interpret. Aegis provides a URL-first workflow, translates findings into business impact, and keeps higher-risk tools behind verification and authorization controls.

## Features

- URL-first passive website security review
- Real streamed scan progress with target, scan ID, timestamps, elapsed time, actual check state, and optional terminal-style telemetry
- Evidence provenance (`live`, `demo`, or `unavailable`) and raw-evidence references on every generated finding
- Conversational explanations and suggested remediation
- Google-style chat suggestions with searchable slash commands and keyboard navigation
- Standalone Aegis email/password accounts with salted password hashes, expiring server-side sessions, and temporary login lockouts
- Website records and findings persisted in Cloudflare D1
- Domain ownership verification by file, DNS TXT, or HTML meta tag, with separate states for Public / Unverified, Ownership Verified, and Active Testing Approved
- Unified findings with New, Open, Fix in Progress, Resolved, Accepted Risk, False Positive, and Returned lifecycle states
- Finding evidence, business impact, technical detail, remediation guidance, verification guidance, and activity history
- Asset inventory for domains, web applications, public services, and certificates observed during assessments
- Per-finding Verify Fix checks that rerun the appropriate authorized passive assessment
- Score change and assessment-coverage reporting without inventing scores for unassessed categories
- Scan-to-scan finding snapshots grouped as New, Resolved, Unchanged, and Regression
- Secure per-scan drill-down for the stored check timeline, finding snapshot, and target-specific raw evidence
- Persistent notification destinations for email, browser, and managed mobile-device workflows
- Dashboard analytics for severity, remediation stage, score trends, assets, authorization records, and credential-free JSON exports
- Data-grounded Aegis analyst responses based on the signed-in user's real findings, scans, and assets
- Downloadable executive and technical PDF reports, evidence JSON, findings CSV, vulnerability reports, and posture reports
- Searchable business security glossary and official-source VPN/security download center
- Draft terms, privacy, authorized-use, and incident-response policies
- Structured scan plans for an isolated FastAPI runner
- Lightweight EDR MVP with endpoint enrollment, authenticated heartbeats, posture alerts, and opt-in file-integrity monitoring
- Passive email-domain scanner for MX, SPF, DMARC, MTA-STS, TLS-RPT, DNSSEC, and selector-based DKIM review
- Weighted cyber-hygiene score and explicit coverage for evidence available to the current assessment; unassessed IAM and backup categories remain excluded
- Conservative SameSite-cookie and third-party script-integrity review items, labeled informational rather than overstated as confirmed exploitation
- Business-friendly capability catalog, with technical engines documented separately under `/tools`
- Guarded Aegis Resolve local patch-agent prototype for a future paid remediation tier
- Raspberry Pi 4B deployment with local persistence, restart-on-boot containers, health checks, backups, and optional HTTPS

## Security tools

| Capability | Integration status | Safety boundary |
| --- | --- | --- |
| Nmap | Adapter source included; runtime-dependent | Verified, allowlisted assets only |
| Nuclei | Adapter source included; runtime-dependent | Curated non-destructive templates |
| testssl.sh | Adapter source included; runtime-dependent | TLS configuration checks |
| theHarvester | Adapter source included; runtime-dependent | Public-source discovery |
| SQLMap | Adapter source included; disabled by default | Verified assets and explicit approval |
| OWASP ZAP | Adapter source included; runtime-dependent | Passive mode by default |
| Burp Suite | Planned integration | Requires a separately licensed service |
| John the Ripper | Planned offline worker | Customer-provided audit files only |
| Hashcat | Planned offline worker | Customer-provided audit files only |
| Nikto | Bounded runner adapter | Verified, allowlisted websites only |
| WhatWeb | Low-intensity adapter | Technology identification only |
| Wapiti | Bounded runner adapter | Verified, allowlisted websites only |
| Gobuster | Bounded runner adapter | Small approved wordlist and request limits |
| WPScan | Bounded runner adapter | Verified WordPress sites only |
| Wafw00f | Low-intensity adapter | Public WAF identification |
| SSLScan | Adapter source included; runtime-dependent | Verified HTTPS services only |
| DIRB | Bounded runner adapter | Small approved wordlist and request limits |
| Feroxbuster | Bounded runner adapter | Shallow, rate-limited discovery |
| JoomScan | Bounded runner adapter | Verified Joomla sites only |

The `/tools` and authenticated `/status` pages report actual web/database/worker state. Scanner binaries are shown as Installed or Not Installed only when a configured worker reports them. The repository includes a privacy-conscious Python endpoint agent and durable EDR dashboard records. IAM, commercial email/web security, backup, and recovery integrations are planned and still require vendor APIs. The EDR agent is an MVP and must be packaged, signed, and independently reviewed before production deployment.

## Endpoint detection and response MVP

The `endpoint-agent/` directory contains a dependency-free Python agent for Windows, macOS, and Linux. An authenticated workspace user creates a device credential that is shown once in the dashboard, then runs the agent on a company-owned device. The agent reports:

- Device and operating-system identity
- Agent version and last heartbeat
- Host-firewall status where the OS exposes it
- Full-disk-encryption status where supported
- Automatic-update status where supported
- Changes to administrator-selected files, without uploading file contents

The backend hashes enrollment secrets before storing them and accepts telemetry only from a matching endpoint token. It creates deduplicated posture alerts when important controls are disabled. See [`endpoint-agent/README.md`](endpoint-agent/README.md) for enrollment instructions.

This MVP deliberately provides human-approved response guidance only. It has no remote shell and cannot kill processes, delete files, collect credentials, or silently change device settings.

## Email security scanner

The public email scanner uses DNS-over-HTTPS to inspect a business domain's published mail safeguards. It does not send messages, access mailboxes, enumerate accounts, or test credentials. Results explain mail routing, authorized senders, anti-spoofing enforcement, encrypted-transport policy, reporting, DNSSEC, and an optional provider-specific DKIM selector.

The scanner is intentionally configuration-focused: it cannot guarantee inbox placement or prove that every outgoing service signs messages correctly. Businesses should validate proposed SPF, DKIM, and DMARC changes with their email provider before enforcement.

## Business accounts and workspace tools

The `/signup` and `/login` routes use an Aegis-owned account rather than Sign in with ChatGPT. Passwords are processed with PBKDF2-HMAC-SHA-256 and a per-account random salt; sessions use random credentials whose hashes are stored in D1 and sent through HttpOnly, SameSite cookies. Repeated login failures trigger a temporary account lockout.

Signed-in users receive a sidebar workspace with a unified findings dashboard, scan history by URL, asset inventory, endpoint monitoring, email scanning, website ownership, and notification preferences. A registered and verified website can run a bounded passive assessment, retain normalized evidence, move findings through a persisted remediation lifecycle, and verify a fix with the matching authorized check.

Authentication remains MVP-level. Production use requires verified email delivery, password recovery, MFA or enterprise SSO, abuse and bot protection, session/device management, account deletion, and an independent review. Aegis now records relevant authorization and workflow audit events, but production audit retention and tamper resistance still need to be designed. Notification preferences are persisted, but production email and SMS delivery still require external messaging providers and verified sending identities.

The `/login` and `/signup` pages are standalone Aegis accounts and do not use ChatGPT or OpenAI sign-in. If an older public deployment still shows an OpenAI sign-in, publish a saved version containing the current account routes or use the Raspberry Pi deployment.

## Guided remediation prototype

The `/resolve` workspace page describes a future paid remediation tier and provides a downloadable local patch agent prototype. The agent has no AI service, network client, billing integration, arbitrary shell, or remote-control channel. It can validate and apply one unified Git patch only when the repository is clean and a person supplies the exact SHA-256 fingerprint printed during preview.

Production remediation requires an authenticated AI service, signed agent releases, customer organization roles, isolated tests, complete audit logs, rollback controls, and independent security review. The prototype must not be represented as autonomous production remediation.

## Architecture

```text
Public visitor ──> Passive HTTPS/header review
                       │
Verified owner ──> Authenticated dashboard ──> D1 records
                       │
                       └──> Structured scan plan
                                  │
                                  └──> Isolated scanner service
                                        ├─ Nmap / Nuclei / testssl
                                        ├─ theHarvester / ZAP / SQLMap
                                        └─ offline John / Hashcat workers
```

The web application never accepts arbitrary shell commands. It sends a structured tool name and validated target to the scanner service, which builds fixed command arguments and enforces an allowlist, timeouts, and output limits.

## Run locally

Requirements:

- Node.js 22+
- pnpm 11+
- Python 3.12+ for the optional scanner service

Install and start the web application:

```bash
pnpm install
pnpm dev
```

The app opens at `http://localhost:3000` unless that port is already occupied.

Build a production bundle:

```bash
pnpm build
```

### Optional scanner service

Execution-disabled mode is the safe default. It returns `EXECUTION_DISABLED` and never substitutes a mock success.

```bash
cd scanner-service
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env
AEGIS_ALLOWED_TARGETS=your-authorized-host.example uvicorn main:app --reload --port 8080
```

Or launch the isolated service with Docker:

```bash
docker compose up --build scanner
```

Setting `AEGIS_LIVE_SCANS=1` is not enough by itself: each target must also be present in `AEGIS_ALLOWED_TARGETS`. Only scan systems you own or have explicit written permission to test.

## Verification

```bash
pnpm lint
pnpm build
pnpm test:security
pnpm test:scanner
pnpm test:hackercon
```

The unit tests cover target isolation, unsafe URL and IP blocking, redirect revalidation, HTTP-to-HTTPS behavior, bounded HTML-signal review, evidence references, cancellation, failure-without-invented-findings, grounded assistant answers, real PDF output, report escaping, exact scanner allowlisting, and execution-disabled behavior. The HackerCon integration suite starts an isolated local worker and disposable D1 database to test secure cookies, authentication boundaries, per-scan evidence access, duplicate registration, ownership gates, scan cooldowns, account lockout, XSS rendering, workspace isolation, and IDOR attempts.

## Host everything on a Raspberry Pi 4B

A separate ARM64-compatible deployment keeps the Aegis application and its account, scan-history, endpoint, and notification database on your Raspberry Pi:

```bash
chmod +x scripts/aegis-pi
./scripts/aegis-pi start
```

Open the LAN address printed by the launcher. Use `./scripts/aegis-pi status`, `logs`, `backup`, `update`, and `stop` for day-to-day operation. See [the Raspberry Pi hosting guide](docs/RASPBERRY_PI.md) for storage, HTTPS, internet-exposure, and security guidance.

## Production work still required

- Connect the web app to the scanner queue with authenticated service-to-service requests
- Run scanners in short-lived isolated workers rather than the web process
- Add organization roles, email verification, recovery, MFA/SSO, tamper-resistant audit retention, distributed rate limits, and session/device management
- Add a durable scheduler and queue for continuous monitoring, cancellation, retry, and emergency termination of long-running jobs
- Move browser-generated PDF reports to an authenticated server-side signing and delivery service for production assurance
- Connect notification preferences to production email, SMS, and web-push providers with retry and delivery logs
- Package and sign the EDR agent, use device certificates and OS secret storage, and add a managed update/uninstall channel
- Add vendor-specific IAM, email, backup, recovery, and commercial EDR connectors
- Add human review and approval for active or credential-audit workflows
- Complete a security review before processing customer data

## Responsible use

Aegis is designed for defensive, authorized assessment. Anonymous visitors receive passive checks only. Active testing must remain restricted to verified assets with explicit authorization. Do not use this project to scan third-party infrastructure without permission.

See [SECURITY.md](SECURITY.md) for reporting and safety requirements and [CONTRIBUTING.md](CONTRIBUTING.md) before proposing a new scanner.

## License

MIT — see [LICENSE](LICENSE).
