"""Scope-enforced local scanner runner for Aegis.

This service accepts structured actions only. It never accepts shell text,
never substitutes a demo result, and refuses execution unless the target is
allowlisted, DNS-safe, explicitly approved, and the engine is installed.
"""
from __future__ import annotations

import ipaddress
import os
import re
import shutil
import socket
import subprocess
import tempfile
import threading
import time
import uuid
from typing import Literal
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Aegis scanner service", version="0.2.0")
SERVICE_VERSION = "0.2.0"
Action = Literal["network_scan", "tls_audit", "web_scan", "osint_discovery", "sql_injection_check", "zap_baseline", "nikto_review", "technology_fingerprint", "wapiti_review", "gobuster_discovery", "wordpress_review", "waf_detection", "sslscan_review", "dirb_discovery", "feroxbuster_discovery", "joomla_review"]

ACTION_ENGINES: dict[str, str] = {
    "network_scan": "nmap", "tls_audit": "testssl.sh", "web_scan": "nuclei",
    "osint_discovery": "theHarvester", "sql_injection_check": "sqlmap",
    "zap_baseline": "zap-baseline.py", "nikto_review": "nikto",
    "technology_fingerprint": "whatweb", "wapiti_review": "wapiti",
    "gobuster_discovery": "gobuster", "wordpress_review": "wpscan",
    "waf_detection": "wafw00f", "sslscan_review": "sslscan",
    "dirb_discovery": "dirb", "feroxbuster_discovery": "feroxbuster",
    "joomla_review": "joomscan",
}
TIMEOUTS = {action: 180 for action in ACTION_ENGINES} | {"network_scan": 120, "technology_fingerprint": 90, "waf_detection": 90}
MAX_OUTPUT = 100_000
COOLDOWN_SECONDS = 60
MAX_CONCURRENT = max(1, min(4, int(os.getenv("AEGIS_MAX_CONCURRENT", "2"))))
execution_slots = threading.BoundedSemaphore(MAX_CONCURRENT)
state_lock = threading.Lock()
last_started: dict[tuple[str, str], float] = {}
last_success: dict[str, str] = {}


class Request(BaseModel):
    action: Action
    target: str = Field(min_length=3, max_length=253)
    approved: bool = False


class CredentialAuditPlan(BaseModel):
    tool: Literal["john", "hashcat"]
    hash_type: str = Field(min_length=1, max_length=60)
    hash_count: int = Field(gt=0, le=1_000_000)
    authorization_confirmed: bool = False


class HygienePlan(BaseModel):
    target: str
    include_endpoints: bool = True
    include_identity: bool = True
    include_email: bool = True
    include_backups: bool = True
    approved: bool = False


def allowed_targets() -> set[str]:
    return {item.strip().lower().rstrip(".") for item in os.getenv("AEGIS_ALLOWED_TARGETS", "").split(",") if item.strip()}


def normalize_target(value: str) -> str:
    raw = value.strip()
    parsed = urlsplit(raw if "://" in raw else f"https://{raw}")
    if parsed.scheme not in {"http", "https"} or parsed.username or parsed.password or parsed.port not in {None, 80, 443}:
        raise HTTPException(400, detail={"code": "INVALID_TARGET", "message": "Use an HTTP(S) hostname on port 80 or 443."})
    target = (parsed.hostname or "").lower().rstrip(".")
    if len(target) > 253 or not re.fullmatch(r"(?=.{3,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", target):
        raise HTTPException(400, detail={"code": "INVALID_TARGET", "message": "Enter a valid hostname, not an IP literal."})
    if target not in allowed_targets():
        raise HTTPException(403, detail={"code": "TARGET_NOT_ALLOWLISTED", "message": "Target is not in the verified execution scope."})
    assert_safe_resolution(target)
    return target


def assert_safe_resolution(target: str) -> None:
    try:
        addresses = {item[4][0] for item in socket.getaddrinfo(target, None, proto=socket.IPPROTO_TCP)}
    except socket.gaierror as exc:
        raise HTTPException(422, detail={"code": "DNS_NOT_FOUND", "message": "Target DNS resolution failed."}) from exc
    if not addresses:
        raise HTTPException(422, detail={"code": "DNS_NOT_FOUND", "message": "Target DNS resolution returned no addresses."})
    allow_private = os.getenv("AEGIS_ALLOW_PRIVATE_TARGETS") == "1"
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if not ip.is_global and not allow_private:
            raise HTTPException(403, detail={"code": "BLOCKED_NETWORK", "message": "Target resolves to a private, loopback, link-local, reserved, or otherwise blocked address."})


def command_for(action: Action, target: str) -> list[str]:
    commands = {
        "network_scan": ["nmap", "-sV", "--top-ports", "100", "--version-light", target],
        "tls_audit": ["testssl.sh", "--quiet", "--warnings", "batch", target],
        "web_scan": ["nuclei", "-u", f"https://{target}", "-severity", "low,medium,high,critical", "-jsonl"],
        "osint_discovery": ["theHarvester", "-d", target, "-b", "crtsh,otx,rapiddns"],
        "sql_injection_check": ["sqlmap", "-u", f"https://{target}", "--batch", "--smart", "--level=1", "--risk=1", "--forms", "--crawl=1"],
        "zap_baseline": ["zap-baseline.py", "-t", f"https://{target}", "-m", "3", "-I"],
        "nikto_review": ["nikto", "-h", f"https://{target}", "-maxtime", "180s", "-nointeractive"],
        "technology_fingerprint": ["whatweb", "--aggression", "1", "--no-errors", f"https://{target}"],
        "wapiti_review": ["wapiti", "-u", f"https://{target}", "--scope", "url", "--max-scan-time", "180"],
        "gobuster_discovery": ["gobuster", "dir", "-u", f"https://{target}", "-w", "/opt/aegis/wordlists/web-small.txt", "-t", "4", "--timeout", "5s", "-q"],
        "wordpress_review": ["wpscan", "--url", f"https://{target}", "--format", "json", "--max-threads", "2", "--no-banner"],
        "waf_detection": ["wafw00f", f"https://{target}", "-o", "-"],
        "sslscan_review": ["sslscan", "--no-colour", "--tlsall", f"{target}:443"],
        "dirb_discovery": ["dirb", f"https://{target}", "/opt/aegis/wordlists/web-small.txt", "-S", "-r"],
        "feroxbuster_discovery": ["feroxbuster", "--url", f"https://{target}", "--wordlist", "/opt/aegis/wordlists/web-small.txt", "--depth", "1", "--threads", "4", "--time-limit", "3m", "--silent", "--json"],
        "joomla_review": ["joomscan", "--url", f"https://{target}", "--ec"],
    }
    return commands[action]


@app.get("/health")
def health():
    live = os.getenv("AEGIS_LIVE_SCANS") == "1"
    return {"ok": True, "version": SERVICE_VERSION, "checked_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "execution": "enabled" if live else "disabled", "allowlisted_targets": len(allowed_targets()), "max_concurrent": MAX_CONCURRENT}


@app.get("/tools")
def tools():
    checked_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    items = []
    for action, engine in ACTION_ENGINES.items():
        installed = shutil.which(engine) is not None
        items.append({"action": action, "engine": engine, "version": None, "status": "installed" if installed else "not_installed", "last_health_check": checked_at, "last_success": last_success.get(action)})
    return {"service_version": SERVICE_VERSION, "checked_at": checked_at, "execution": "enabled" if os.getenv("AEGIS_LIVE_SCANS") == "1" else "disabled", "tools": items, "offline_auditors": [{"engine": engine, "version": None, "status": "installed" if shutil.which(engine) else "not_installed", "last_health_check": checked_at} for engine in ("john", "hashcat")], "external_integrations": [{"name": "Burp Suite", "status": "planned"}]}


@app.post("/credential-audit/plan")
def credential_audit_plan(request: CredentialAuditPlan):
    if not request.authorization_confirmed:
        raise HTTPException(409, detail={"code": "AUTHORIZATION_REQUIRED", "message": "Written authorization for the supplied hashes is required."})
    return {"tool": request.tool, "hash_type": request.hash_type, "hash_count": request.hash_count, "execution": "isolated_offline_worker", "network_access": "disabled", "requires_uploaded_hashes": True, "requires_final_approval": True, "status": "plan_only"}


@app.post("/hygiene/plan")
def hygiene_plan(request: HygienePlan):
    target = normalize_target(request.target)
    if not request.approved:
        raise HTTPException(409, detail={"code": "APPROVAL_REQUIRED", "message": "Explicit approval for the verified target is required."})
    checks = [{"area": "website_network", "actions": ["network_scan", "tls_audit", "web_scan", "osint_discovery"], "execution": "scope_enforced_runner"}, {"area": "email_web", "actions": ["spf_dkim_dmarc", "security_headers"], "execution": "passive_review"}]
    if request.include_endpoints: checks.append({"area": "endpoints", "actions": ["agent_coverage", "active_alerts", "sensor_health"], "execution": "aegis_agent"})
    if request.include_identity: checks.append({"area": "identity", "actions": ["mfa_coverage", "inactive_admins", "privilege_review"], "execution": "planned_connector"})
    if request.include_backups: checks.append({"area": "backup_recovery", "actions": ["backup_freshness", "restore_test_age", "isolation_posture"], "execution": "planned_connector"})
    return {"target": target, "assessment": "cyber_hygiene", "checks": checks, "status": "plan_only", "requires_human_review": True}


@app.post("/plan")
def plan(request: Request):
    target = normalize_target(request.target)
    engine = ACTION_ENGINES[request.action]
    return {"action": request.action, "target": target, "profile": "bounded", "engine": engine, "engine_status": "installed" if shutil.which(engine) else "not_installed", "requires_approval": True, "timeout_seconds": TIMEOUTS[request.action], "output_limit_bytes": MAX_OUTPUT}


@app.post("/execute")
def execute(request: Request):
    request_id = str(uuid.uuid4())
    target = normalize_target(request.target)
    if not request.approved:
        raise HTTPException(409, detail={"code": "APPROVAL_REQUIRED", "message": "Explicit approval is required."})
    if os.getenv("AEGIS_LIVE_SCANS") != "1":
        raise HTTPException(503, detail={"code": "EXECUTION_DISABLED", "message": "Scanner execution is disabled; no scan was run."})
    command = command_for(request.action, target)
    if shutil.which(command[0]) is None:
        raise HTTPException(424, detail={"code": "ENGINE_NOT_INSTALLED", "message": f"Approved scanner is not installed: {command[0]}"})
    now = time.monotonic()
    with state_lock:
        prior = last_started.get((request.action, target), 0)
        if now - prior < COOLDOWN_SECONDS:
            raise HTTPException(429, detail={"code": "TARGET_COOLDOWN", "message": f"Wait {int(COOLDOWN_SECONDS - (now - prior)) + 1} seconds before rerunning this action."})
        last_started[(request.action, target)] = now
    if not execution_slots.acquire(blocking=False):
        raise HTTPException(429, detail={"code": "CONCURRENCY_LIMIT", "message": "The scanner worker is at its concurrency limit."})
    try:
        with tempfile.TemporaryDirectory(prefix="aegis-scan-") as workdir:
            try:
                result = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=TIMEOUTS[request.action], check=False, cwd=workdir, env={"PATH": os.getenv("PATH", ""), "LANG": "C.UTF-8", "TMPDIR": workdir, "XDG_CACHE_HOME": workdir})
            except subprocess.TimeoutExpired as exc:
                raise HTTPException(408, detail={"code": "SCANNER_TIMEOUT", "message": "Scanner exceeded its bounded time limit."}) from exc
        if result.returncode == 0:
            with state_lock: last_success[request.action] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        return {"request_id": request_id, "status": "completed" if result.returncode == 0 else "failed", "action": request.action, "target": target, "engine": command[0], "exit_code": result.returncode, "stdout": result.stdout[-MAX_OUTPUT:], "stderr": result.stderr[-10_000:], "truncated": len(result.stdout) > MAX_OUTPUT}
    finally:
        execution_slots.release()
