import importlib.util
import os
import socket
import sys
import types
import unittest
from unittest.mock import patch


class HTTPException(Exception):
    def __init__(self, status_code, detail=None):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


class FastAPI:
    def __init__(self, **_kwargs): pass
    def get(self, _path): return lambda function: function
    def post(self, _path): return lambda function: function


class BaseModel: pass


sys.modules.setdefault("fastapi", types.SimpleNamespace(FastAPI=FastAPI, HTTPException=HTTPException))
sys.modules.setdefault("pydantic", types.SimpleNamespace(BaseModel=BaseModel, Field=lambda **_kwargs: None))
spec = importlib.util.spec_from_file_location("aegis_scanner", os.path.join(os.path.dirname(__file__), "main.py"))
scanner = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(scanner)


PUBLIC_DNS = [(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, "", ("93.184.216.34", 0))]
PRIVATE_DNS = [(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, "", ("127.0.0.1", 0))]


class ScannerPolicyTests(unittest.TestCase):
    def test_requires_exact_allowlist(self):
        with patch.dict(os.environ, {"AEGIS_ALLOWED_TARGETS": "allowed.example.com"}, clear=False), patch.object(socket, "getaddrinfo", return_value=PUBLIC_DNS):
            self.assertEqual(scanner.normalize_target("https://allowed.example.com"), "allowed.example.com")
            with self.assertRaises(HTTPException) as caught: scanner.normalize_target("other.example.com")
            self.assertEqual(caught.exception.status_code, 403)

    def test_blocks_private_dns_even_when_allowlisted(self):
        with patch.dict(os.environ, {"AEGIS_ALLOWED_TARGETS": "internal.example.com", "AEGIS_ALLOW_PRIVATE_TARGETS": "0"}, clear=False), patch.object(socket, "getaddrinfo", return_value=PRIVATE_DNS):
            with self.assertRaises(HTTPException) as caught: scanner.normalize_target("internal.example.com")
            self.assertEqual(caught.exception.detail["code"], "BLOCKED_NETWORK")

    def test_fixed_command_is_an_argument_list(self):
        command = scanner.command_for("network_scan", "allowed.example.com")
        self.assertIsInstance(command, list)
        self.assertEqual(command[0], "nmap")
        self.assertNotIn("shell", " ".join(command))

    def test_disabled_execution_never_returns_mock_success(self):
        request = types.SimpleNamespace(action="network_scan", target="allowed.example.com", approved=True)
        with patch.dict(os.environ, {"AEGIS_ALLOWED_TARGETS": "allowed.example.com", "AEGIS_LIVE_SCANS": "0"}, clear=False), patch.object(socket, "getaddrinfo", return_value=PUBLIC_DNS):
            with self.assertRaises(HTTPException) as caught: scanner.execute(request)
            self.assertEqual(caught.exception.status_code, 503)
            self.assertEqual(caught.exception.detail["code"], "EXECUTION_DISABLED")


if __name__ == "__main__": unittest.main()
