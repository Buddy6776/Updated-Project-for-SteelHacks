CREATE TABLE `public_scans` (
	`id` text PRIMARY KEY NOT NULL,
	`target` text NOT NULL,
	`requested_url` text NOT NULL,
	`status` text NOT NULL,
	`provenance` text DEFAULT 'live' NOT NULL,
	`score` integer,
	`coverage` integer,
	`finding_count` integer DEFAULT 0 NOT NULL,
	`summary_json` text,
	`error_code` text,
	`error_message` text,
	`client_hash` text NOT NULL,
	`started_at` text NOT NULL,
	`completed_at` text,
	`expires_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_public_scans_target_started` ON `public_scans` (`target`,`started_at`);--> statement-breakpoint
CREATE INDEX `idx_public_scans_client_started` ON `public_scans` (`client_hash`,`started_at`);--> statement-breakpoint
CREATE INDEX `idx_public_scans_expiry` ON `public_scans` (`expires_at`);--> statement-breakpoint
CREATE TABLE `scan_evidence` (
	`id` text PRIMARY KEY NOT NULL,
	`scan_id` text NOT NULL,
	`user_id` text,
	`website_id` text,
	`target` text NOT NULL,
	`source` text NOT NULL,
	`check_key` text NOT NULL,
	`status` text NOT NULL,
	`evidence_json` text NOT NULL,
	`provenance` text NOT NULL,
	`observed_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_scan_evidence_scan` ON `scan_evidence` (`scan_id`);--> statement-breakpoint
CREATE INDEX `idx_scan_evidence_user_observed` ON `scan_evidence` (`user_id`,`observed_at`);--> statement-breakpoint
CREATE INDEX `idx_scan_evidence_target_observed` ON `scan_evidence` (`target`,`observed_at`);--> statement-breakpoint
ALTER TABLE `scans` ADD `target` text;--> statement-breakpoint
ALTER TABLE `scans` ADD `provenance` text DEFAULT 'live' NOT NULL;--> statement-breakpoint
ALTER TABLE `scans` ADD `coverage` integer;--> statement-breakpoint
ALTER TABLE `scans` ADD `checks_json` text;--> statement-breakpoint
ALTER TABLE `scans` ADD `error_code` text;--> statement-breakpoint
ALTER TABLE `scans` ADD `error_message` text;--> statement-breakpoint
ALTER TABLE `websites` ADD `verification_state` text DEFAULT 'public_unverified' NOT NULL;--> statement-breakpoint
ALTER TABLE `websites` ADD `verification_method` text;--> statement-breakpoint
ALTER TABLE `websites` ADD `active_testing_approved` integer DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `websites` ADD `active_testing_approved_at` text;--> statement-breakpoint
ALTER TABLE `websites` ADD `active_testing_approved_by` text;--> statement-breakpoint
ALTER TABLE `websites` ADD `suspended_at` text;--> statement-breakpoint
UPDATE `websites` SET `verification_state` = CASE WHEN `verified` = 1 THEN 'ownership_verified' ELSE 'public_unverified' END;--> statement-breakpoint
UPDATE `scans` SET `target` = replace(replace(`url`, 'https://', ''), 'http://', '') WHERE `target` IS NULL;--> statement-breakpoint
PRAGMA optimize;
