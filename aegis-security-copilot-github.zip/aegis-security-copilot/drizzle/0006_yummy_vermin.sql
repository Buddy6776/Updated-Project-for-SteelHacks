CREATE TABLE `auth_rate_limits` (
	`key_hash` text PRIMARY KEY NOT NULL,
	`action` text NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`window_started_at` text NOT NULL,
	`blocked_until` text,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_auth_rate_limits_updated` ON `auth_rate_limits` (`updated_at`);--> statement-breakpoint
ALTER TABLE `accounts` ADD `email_verified_at` text;--> statement-breakpoint
ALTER TABLE `accounts` ADD `mfa_enabled` integer DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `accounts` ADD `recovery_codes_generated_at` text;--> statement-breakpoint
ALTER TABLE `accounts` ADD `password_changed_at` text;--> statement-breakpoint
ALTER TABLE `sessions` ADD `user_agent_hash` text;--> statement-breakpoint
ALTER TABLE `sessions` ADD `ip_hash` text;--> statement-breakpoint
ALTER TABLE `sessions` ADD `last_seen_at` text;--> statement-breakpoint
ALTER TABLE `sessions` ADD `revoked_at` text;--> statement-breakpoint
UPDATE `accounts` SET `password_changed_at` = `created_at` WHERE `password_changed_at` IS NULL;--> statement-breakpoint
UPDATE `sessions` SET `last_seen_at` = `created_at` WHERE `last_seen_at` IS NULL;--> statement-breakpoint
PRAGMA optimize;
