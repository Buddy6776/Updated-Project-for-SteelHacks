CREATE TABLE `scan_finding_snapshots` (
	`id` text PRIMARY KEY NOT NULL,
	`scan_id` text NOT NULL,
	`user_id` text NOT NULL,
	`website_id` text NOT NULL,
	`finding_type` text NOT NULL,
	`title` text NOT NULL,
	`severity` text NOT NULL,
	`status` text NOT NULL,
	`present` integer NOT NULL,
	`observed_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_scan_finding_snapshot_unique` ON `scan_finding_snapshots` (`scan_id`,`finding_type`);--> statement-breakpoint
CREATE INDEX `idx_scan_finding_snapshot_user` ON `scan_finding_snapshots` (`user_id`,`website_id`,`observed_at`);--> statement-breakpoint
PRAGMA optimize;
