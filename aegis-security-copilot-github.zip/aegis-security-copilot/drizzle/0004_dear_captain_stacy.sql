CREATE TABLE `assets` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`website_id` text,
	`asset_type` text NOT NULL,
	`value` text NOT NULL,
	`display_name` text NOT NULL,
	`source` text NOT NULL,
	`risk_level` text DEFAULT 'informational' NOT NULL,
	`monitoring_enabled` integer DEFAULT false NOT NULL,
	`first_seen_at` text NOT NULL,
	`last_checked_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_assets_user_type_value` ON `assets` (`user_id`,`asset_type`,`value`);--> statement-breakpoint
CREATE INDEX `idx_assets_user_last_checked` ON `assets` (`user_id`,`last_checked_at`);--> statement-breakpoint
CREATE INDEX `idx_assets_website` ON `assets` (`website_id`);--> statement-breakpoint
CREATE TABLE `audit_events` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`website_id` text,
	`event_type` text NOT NULL,
	`detail` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_audit_events_user_created` ON `audit_events` (`user_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_audit_events_website_created` ON `audit_events` (`website_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `finding_activity` (
	`id` text PRIMARY KEY NOT NULL,
	`finding_id` text NOT NULL,
	`user_id` text NOT NULL,
	`action` text NOT NULL,
	`from_status` text,
	`to_status` text,
	`detail` text NOT NULL,
	`actor_type` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_finding_activity_finding_created` ON `finding_activity` (`finding_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_finding_activity_user_created` ON `finding_activity` (`user_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `scan_authorizations` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`website_id` text NOT NULL,
	`hostname` text NOT NULL,
	`scope` text NOT NULL,
	`authorized_by` text NOT NULL,
	`authorized_at` text NOT NULL,
	`expires_at` text,
	`revoked_at` text
);
--> statement-breakpoint
CREATE INDEX `idx_scan_authorizations_scope` ON `scan_authorizations` (`user_id`,`website_id`,`revoked_at`);--> statement-breakpoint
CREATE INDEX `idx_scan_authorizations_expiry` ON `scan_authorizations` (`expires_at`);--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `asset_id` text;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `category` text DEFAULT 'website_security' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `confidence` text DEFAULT 'high' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `description` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `scanner` text DEFAULT 'aegis_passive_web' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `evidence` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `business_impact` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `technical_explanation` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `remediation` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `verification_guidance` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `cve` text;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `cwe` text;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `cvss` text;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `raw_output_reference` text;--> statement-breakpoint
ALTER TABLE `vulnerabilities` ADD `last_seen_at` text DEFAULT 'legacy' NOT NULL;--> statement-breakpoint
CREATE INDEX `idx_vulnerabilities_user_category` ON `vulnerabilities` (`user_id`,`category`);--> statement-breakpoint
CREATE INDEX `idx_vulnerabilities_asset_status` ON `vulnerabilities` (`asset_id`,`status`);--> statement-breakpoint
UPDATE `vulnerabilities` SET `last_seen_at` = `updated_at` WHERE `last_seen_at` = 'legacy';--> statement-breakpoint
PRAGMA optimize;
