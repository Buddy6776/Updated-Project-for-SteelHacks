import { requireAegisUser } from '../business-auth';
import ScannerStatus from '../scanner-status';
export const dynamic='force-dynamic';
export default async function StatusPage(){await requireAegisUser('/status');return <main className="technical-tools-page status-page"><header><a href="/dashboard">← Workspace</a><div><span>INTERNAL STATUS</span><h1>Aegis system status</h1><p>Operational truth for the web service, database, passive checks, scanner worker, installed engines, and planned integrations.</p></div><a className="workspace-link" href="/tools">Technical details →</a></header><ScannerStatus/></main>}
