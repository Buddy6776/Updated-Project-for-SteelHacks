export type SecurityTool={mark:string;name:string;category:string;description:string;status:'Available'|'Beta'|'Coming Soon';access:string;docs?:string};

export const securityTools:SecurityTool[]=[
 {mark:'NM',name:'Nmap',category:'Network exposure',description:'Maps exposed services and software versions on verified company systems.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/nmap/'},
 {mark:'NU',name:'Nuclei',category:'Vulnerability detection',description:'Runs curated, non-destructive checks for known website and API issues.',status:'Beta',access:'Authorization required'},
 {mark:'TS',name:'testssl.sh',category:'Encryption / TLS',description:'Reviews TLS protocols, certificates, ciphers, and encryption weaknesses.',status:'Beta',access:'Authorization required'},
 {mark:'TH',name:'theHarvester',category:'Asset discovery',description:'Discovers public subdomains and internet-facing business assets without exploitation.',status:'Beta',access:'Public signals or authorized scope'},
 {mark:'SQ',name:'SQLMap',category:'Website security',description:'Performs bounded SQL injection detection after ownership verification and approval.',status:'Beta',access:'Authorization required'},
 {mark:'ZP',name:'OWASP ZAP',category:'Website security',description:'Provides a safe baseline review with an authorized path to deeper testing.',status:'Beta',access:'Public signals or authorized scope'},
 {mark:'BP',name:'Burp Suite',category:'Website security',description:'Planned licensed integration for professional application-security workflows.',status:'Coming Soon',access:'Planned integration'},
 {mark:'JR',name:'John the Ripper',category:'Password security',description:'Audits customer-provided hashes inside an isolated, offline environment.',status:'Coming Soon',access:'Customer-provided data only'},
 {mark:'HC',name:'Hashcat',category:'Password security',description:'Audits password strength for authorized, customer-provided hash sets.',status:'Coming Soon',access:'Customer-provided data only'},
 {mark:'NK',name:'Nikto',category:'Website security',description:'Checks verified web servers for known risky files, defaults, and version indicators.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/nikto/'},
 {mark:'WW',name:'WhatWeb',category:'Asset discovery',description:'Identifies public website technologies for accurate remediation guidance.',status:'Beta',access:'Public signals or authorized scope',docs:'https://www.kali.org/tools/whatweb/'},
 {mark:'WA',name:'Wapiti',category:'Website security',description:'Performs a bounded crawl for common application weaknesses.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/wapiti/'},
 {mark:'GB',name:'Gobuster',category:'Asset discovery',description:'Looks for unlinked website paths with a small approved wordlist and strict limits.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/gobuster/'},
 {mark:'WP',name:'WPScan',category:'Vulnerability detection',description:'Reviews verified WordPress sites for versions, components, and known advisories.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/wpscan/'},
 {mark:'WF',name:'Wafw00f',category:'Network exposure',description:'Detects whether a public website appears to use a web application firewall.',status:'Beta',access:'Public signals or authorized scope',docs:'https://www.kali.org/tools/wafw00f/'},
 {mark:'SS',name:'SSLScan',category:'Encryption / TLS',description:'Summarizes supported TLS protocols and ciphers for an approved HTTPS service.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/sslscan/'},
 {mark:'DB',name:'DIRB',category:'Asset discovery',description:'Runs a tightly bounded content review against an explicitly approved website.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/dirb/'},
 {mark:'FX',name:'Feroxbuster',category:'Asset discovery',description:'Performs rate-limited recursive discovery with a shallow approved scope.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/feroxbuster/'},
 {mark:'JM',name:'JoomScan',category:'Vulnerability detection',description:'Checks a verified Joomla site for public version and component risk indicators.',status:'Beta',access:'Authorization required',docs:'https://www.kali.org/tools/joomscan/'},
];

export const capabilityGroups=[
 {name:'Website Security',description:'Review browser protections, application configuration, and authorized web risks.'},
 {name:'Network Exposure',description:'Understand which business services are publicly reachable.'},
 {name:'Vulnerability Detection',description:'Correlate known issues into normalized Aegis findings.'},
 {name:'Email Security',description:'Check spoofing protection, mail routing, and DNS safeguards.'},
 {name:'Encryption / TLS',description:'Review certificates, protocols, ciphers, and renewal posture.'},
 {name:'Identity & Access',description:'Measure MFA, privileged access, and account hygiene. Coming Soon.'},
 {name:'Endpoint Security',description:'Track enrolled-device posture and important endpoint alerts.'},
 {name:'Backup & Recovery',description:'Measure backup freshness and restore readiness. Coming Soon.'},
];
