import { env } from 'cloudflare:workers';
import { getAegisUser } from '../../../business-auth';

type StoredScan={id:string;websiteId:string|null;url:string;target:string|null;scanType:string;status:string;provenance:string;coverage:number|null;findingCount:number;score:number|null;checksJson:string|null;errorCode:string|null;errorMessage:string|null;startedAt:string;completedAt:string|null};
type StoredEvidence={id:string;scanId:string;websiteId:string|null;target:string;source:string;checkKey:string;status:string;evidenceJson:string;provenance:string;observedAt:string};

export async function GET(request:Request){
 const user=await getAegisUser();if(!user)return Response.json({error:'Authentication required'},{status:401});
 const rawScanId=new URL(request.url).pathname.split('/').filter(Boolean).at(-1)??'';let scanId='';try{scanId=decodeURIComponent(rawScanId)}catch{return Response.json({error:'Scan not found'},{status:404})}if(!scanId||scanId.length>128)return Response.json({error:'Scan not found'},{status:404});
 const scan=await env.DB.prepare('SELECT id,website_id AS websiteId,url,target,scan_type AS scanType,status,provenance,coverage,finding_count AS findingCount,score,checks_json AS checksJson,error_code AS errorCode,error_message AS errorMessage,started_at AS startedAt,completed_at AS completedAt FROM scans WHERE id=? AND user_id=?').bind(scanId,user.userId).first<StoredScan>();
 if(!scan)return Response.json({error:'Scan not found'},{status:404});
 const[evidenceRows,snapshotRows]=await Promise.all([
  env.DB.prepare('SELECT id,scan_id AS scanId,website_id AS websiteId,target,source,check_key AS checkKey,status,evidence_json AS evidenceJson,provenance,observed_at AS observedAt FROM scan_evidence WHERE scan_id=? AND user_id=? ORDER BY observed_at,id LIMIT 200').bind(scanId,user.userId).all<StoredEvidence>(),
  env.DB.prepare('SELECT id,scan_id AS scanId,website_id AS websiteId,finding_type AS findingType,title,severity,status,present,observed_at AS observedAt FROM scan_finding_snapshots WHERE scan_id=? AND user_id=? ORDER BY present DESC,severity,title LIMIT 200').bind(scanId,user.userId).all(),
 ]);
 const checks=parseArray(scan.checksJson);const evidence=evidenceRows.results.map(item=>{const{evidenceJson,...stored}=item;return{...stored,observedValue:parseObject(evidenceJson)}});
 return Response.json({scan:{...scan,checksJson:undefined,checks},evidence,snapshots:snapshotRows.results},{headers:{'cache-control':'private, no-store'}});
}

function parseArray(value:string|null){try{const parsed=JSON.parse(value??'[]');return Array.isArray(parsed)?parsed:[]}catch{return[]}}
function parseObject(value:string){try{const parsed=JSON.parse(value);return parsed&&typeof parsed==='object'&&!Array.isArray(parsed)?parsed:{value:parsed}}catch{return{unavailable:'Stored evidence could not be decoded.'}}}
