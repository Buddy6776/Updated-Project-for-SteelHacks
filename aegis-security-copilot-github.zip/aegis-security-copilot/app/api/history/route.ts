import { env } from 'cloudflare:workers';
import { getAegisUser } from '../../business-auth';

const findingSelect='SELECT id,website_id AS websiteId,asset_id AS assetId,url,type,category,severity,confidence,title,description,scanner,evidence,business_impact AS businessImpact,technical_explanation AS technicalExplanation,remediation,verification_guidance AS verificationGuidance,cve,cwe,cvss,raw_output_reference AS rawOutputReference,status,detected_at AS detectedAt,last_seen_at AS lastSeenAt,updated_at AS updatedAt FROM vulnerabilities';

export async function GET(){
 const user=await getAegisUser();if(!user)return Response.json({error:'Authentication required'},{status:401});
 const [vulnerabilities,scans,assets,activity,authorizations,audit]=await Promise.all([
  env.DB.prepare(`${findingSelect} WHERE user_id=? ORDER BY updated_at DESC LIMIT 500`).bind(user.userId).all(),
  env.DB.prepare('SELECT id,website_id AS websiteId,url,target,scan_type AS scanType,status,provenance,coverage,checks_json AS checksJson,finding_count AS findingCount,score,error_code AS errorCode,error_message AS errorMessage,started_at AS startedAt,completed_at AS completedAt FROM scans WHERE user_id=? ORDER BY started_at DESC LIMIT 500').bind(user.userId).all(),
  env.DB.prepare('SELECT a.id,a.website_id AS websiteId,a.asset_type AS assetType,a.value,a.display_name AS displayName,a.source,a.risk_level AS riskLevel,a.monitoring_enabled AS monitoringEnabled,a.first_seen_at AS firstSeenAt,a.last_checked_at AS lastCheckedAt,COUNT(v.id) AS findingCount FROM assets a LEFT JOIN vulnerabilities v ON v.asset_id=a.id AND v.status IN (\'new\',\'open\',\'fix_in_progress\',\'returned\',\'accepted_risk\') WHERE a.user_id=? GROUP BY a.id ORDER BY a.first_seen_at DESC LIMIT 500').bind(user.userId).all(),
  env.DB.prepare('SELECT id,finding_id AS findingId,action,from_status AS fromStatus,to_status AS toStatus,detail,actor_type AS actorType,created_at AS createdAt FROM finding_activity WHERE user_id=? ORDER BY created_at DESC LIMIT 1000').bind(user.userId).all(),
  env.DB.prepare('SELECT id,website_id AS websiteId,hostname,scope,authorized_by AS authorizedBy,authorized_at AS authorizedAt,expires_at AS expiresAt,revoked_at AS revokedAt FROM scan_authorizations WHERE user_id=? ORDER BY authorized_at DESC LIMIT 100').bind(user.userId).all(),
  env.DB.prepare('SELECT id,website_id AS websiteId,event_type AS eventType,detail,created_at AS createdAt FROM audit_events WHERE user_id=? ORDER BY created_at DESC LIMIT 100').bind(user.userId).all(),
 ]);
 return Response.json({vulnerabilities:vulnerabilities.results,scans:scans.results,assets:assets.results,activity:activity.results,authorizations:authorizations.results,audit:audit.results});
}

export async function PATCH(request:Request){
 const user=await getAegisUser();if(!user)return Response.json({error:'Authentication required'},{status:401});
 const body=await request.json() as {id?:unknown;status?:unknown};const allowed=new Set(['open','fix_in_progress','accepted_risk','false_positive']);
 if(typeof body.id!=='string'||typeof body.status!=='string'||!allowed.has(body.status))return Response.json({error:'Choose a supported finding status.'},{status:400});
 const finding=await env.DB.prepare('SELECT id,website_id AS websiteId,status,title FROM vulnerabilities WHERE id=? AND user_id=?').bind(body.id,user.userId).first<{id:string;websiteId:string|null;status:string;title:string}>();if(!finding)return Response.json({error:'Finding not found'},{status:404});
 const changedAt=new Date().toISOString();await env.DB.batch([env.DB.prepare('UPDATE vulnerabilities SET status=?,updated_at=? WHERE id=? AND user_id=?').bind(body.status,changedAt,finding.id,user.userId),env.DB.prepare("INSERT INTO finding_activity (id,finding_id,user_id,action,from_status,to_status,detail,actor_type,created_at) VALUES (?,?,?,'user_status_change',?,?,?,?,?)").bind(crypto.randomUUID(),finding.id,user.userId,finding.status,body.status,`User changed finding status to ${body.status}.`,'user',changedAt),env.DB.prepare('INSERT INTO audit_events (id,user_id,website_id,event_type,detail,created_at) VALUES (?,?,?,?,?,?)').bind(crypto.randomUUID(),user.userId,finding.websiteId,'finding_status_changed',`${finding.title}: ${finding.status} → ${body.status}.`,changedAt)]);
 return Response.json({finding:{id:finding.id,status:body.status,updatedAt:changedAt}});
}
