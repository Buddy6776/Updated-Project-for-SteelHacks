import { runPublicCheck } from '../../security/public-check';
import { normalizePublicTarget,TargetSafetyError } from '../../security/target-safety';
export async function POST(request:Request){
 let body:{url?:unknown};try{body=await request.json() as {url?:unknown}}catch{return Response.json({code:'INVALID_REQUEST',error:'Send a website address as JSON.'},{status:400})}
 if(typeof body.url!=='string')return Response.json({code:'INVALID_URL',error:'Enter a valid public business website.'},{status:400});
 try{const target=normalizePublicTarget(body.url);return Response.json(await runPublicCheck(target.url),{headers:{'cache-control':'no-store'}})}catch(error){if(error instanceof TargetSafetyError)return Response.json({code:error.code,error:error.message},{status:error.httpStatus});return Response.json({code:'SCAN_UNAVAILABLE',error:error instanceof Error?error.message:'The public review could not be completed.'},{status:422})}
}
