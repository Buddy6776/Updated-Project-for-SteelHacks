import { env } from 'cloudflare:workers';
import { runPublicCheck,type ScanEvidence,type ScanProgressEvent } from '../../../security/public-check';
import { normalizePublicTarget,TargetSafetyError } from '../../../security/target-safety';

const PUBLIC_SCAN_TTL_MS=7*24*60*60*1000;
const CHECKS=[
 {id:'dns',label:'Resolving DNS'},
 {id:'https',label:'Checking HTTPS and redirects'},
 {id:'http_redirect',label:'Checking HTTP to HTTPS redirect'},
 {id:'headers',label:'Analyzing security headers'},
 {id:'technology',label:'Checking exposed technologies'},
 {id:'html',label:'Reviewing basic HTML security signals'},
 {id:'email',label:'Checking email security'},
 {id:'correlation',label:'Correlating evidence into findings'},
 {id:'summary',label:'Aegis generating grounded remediation summary'},
];

export async function POST(request:Request){
 let body:{url?:unknown};
 try{body=await request.json() as {url?:unknown}}catch{return Response.json({code:'INVALID_REQUEST',error:'Send a website address as JSON.'},{status:400})}
 if(typeof body.url!=='string'||body.url.length>4096)return Response.json({code:'INVALID_URL',error:'Enter a valid public business website.'},{status:400});
 let target:ReturnType<typeof normalizePublicTarget>;
 try{target=normalizePublicTarget(body.url)}catch(error){return targetError(error)}
 const clientHash=await clientFingerprint(request);const limit=await enforceRatePolicy(clientHash,target.hostname);
 if(limit)return Response.json({code:limit.code,error:limit.message},{status:429,headers:{'retry-after':String(limit.retryAfter)}});
 const scanId=crypto.randomUUID();const startedAt=new Date().toISOString();const expiresAt=new Date(Date.now()+PUBLIC_SCAN_TTL_MS).toISOString();
 await env.DB.prepare("INSERT INTO public_scans (id,target,requested_url,status,provenance,client_hash,started_at,expires_at) VALUES (?,?,?,'in_progress','live',?,?,?)").bind(scanId,target.hostname,target.url,clientHash,startedAt,expiresAt).run();
 const stream=new TransformStream();const writer=stream.writable.getWriter();const encoder=new TextEncoder();
 const emit=async(payload:unknown)=>writer.write(encoder.encode(`${JSON.stringify(payload)}\n`));
 void(async()=>{
  try{
   await emit({type:'started',scanId,target:target.hostname,requestedUrl:target.url,startedAt,provenance:'live',checks:CHECKS.map(check=>({...check,status:'pending'}))});
   const onProgress=async(event:ScanProgressEvent)=>emit(event);
   const result=await runPublicCheck(target.url,{scanId,startedAt,onProgress,signal:request.signal});
   await persistEvidence(result.evidence);
   await env.DB.prepare("UPDATE public_scans SET status='completed',score=?,coverage=?,finding_count=?,summary_json=?,completed_at=? WHERE id=?").bind(result.score,result.coverage,result.findings.length,JSON.stringify(result.summary),result.completedAt,scanId).run();
   await emit({type:'complete',result});
  }catch(error){
   const failure=scanError(error);const completedAt=new Date().toISOString();
   await env.DB.prepare("UPDATE public_scans SET status='failed',provenance='unavailable',error_code=?,error_message=?,completed_at=? WHERE id=?").bind(failure.code,failure.message,completedAt,scanId).run().catch(()=>undefined);
   await emit({type:'error',scanId,target:target.hostname,completedAt,...failure}).catch(()=>undefined);
  }finally{await writer.close().catch(()=>undefined)}
 })();
 return new Response(stream.readable,{headers:{'content-type':'application/x-ndjson; charset=utf-8','cache-control':'no-store, private','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'"}});
}

async function persistEvidence(evidence:ScanEvidence[]){
 if(!evidence.length)return;
 await env.DB.batch(evidence.map(item=>env.DB.prepare('INSERT INTO scan_evidence (id,scan_id,target,source,check_key,status,evidence_json,provenance,observed_at) VALUES (?,?,?,?,?,?,?,?,?)').bind(item.id,item.scanId,item.target,item.source,item.checkKey,item.status,JSON.stringify(item.observedValue),item.provenance,item.observedAt)));
}

async function enforceRatePolicy(clientHash:string,target:string){
 const now=Date.now();const hourAgo=new Date(now-60*60*1000).toISOString();const tenMinutesAgo=new Date(now-10*60*1000).toISOString();const twoMinutesAgo=new Date(now-2*60*1000).toISOString();
 const [client,targetCount,concurrent]=await Promise.all([
  env.DB.prepare('SELECT COUNT(*) AS count FROM public_scans WHERE client_hash=? AND started_at>?').bind(clientHash,hourAgo).first<{count:number}>(),
  env.DB.prepare('SELECT COUNT(*) AS count FROM public_scans WHERE target=? AND started_at>?').bind(target,tenMinutesAgo).first<{count:number}>(),
  env.DB.prepare("SELECT COUNT(*) AS count FROM public_scans WHERE client_hash=? AND status='in_progress' AND started_at>?").bind(clientHash,twoMinutesAgo).first<{count:number}>(),
 ]);
 if((concurrent?.count??0)>=2)return{code:'TOO_MANY_CONCURRENT_SCANS',message:'Two reviews are already running. Wait for one to finish.',retryAfter:30};
 if((client?.count??0)>=5)return{code:'CLIENT_RATE_LIMIT',message:'Public review limit reached. Try again in an hour or sign in for saved assessments.',retryAfter:3600};
 if((targetCount?.count??0)>=3)return{code:'TARGET_COOLDOWN',message:'This website was reviewed recently. Wait 10 minutes before checking it again.',retryAfter:600};
 return null;
}

async function clientFingerprint(request:Request){const source=request.headers.get('cf-connecting-ip')??request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()??'unknown';const agent=(request.headers.get('user-agent')??'unknown').slice(0,180);const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(`${source}|${agent}`));return[...new Uint8Array(digest)].map(byte=>byte.toString(16).padStart(2,'0')).join('')}
function scanError(error:unknown){if(error instanceof TargetSafetyError)return{code:error.code,message:error.message};return{code:'SCAN_UNAVAILABLE',message:error instanceof Error?error.message:'The public review could not be completed.'}}
function targetError(error:unknown){const failure=scanError(error);const status=error instanceof TargetSafetyError?error.httpStatus:400;return Response.json({code:failure.code,error:failure.message},{status})}
