'use client';
/* eslint-disable @next/next/no-html-link-for-pages -- full-page navigation avoids a hosted client-router failure */


export default function PortalSidebar({active,displayName,email}:{active:'learn'|'downloads'|'resolve';displayName:string;email:string}){
 async function signOut(){await fetch('/api/auth/logout',{method:'POST'});window.location.assign('/')}
 return <aside className="portal-sidebar">
  <a className="dash-brand" href="/"><span>A</span><div><strong>Aegis</strong><small>Security Copilot</small></div></a>
  <nav>
   <p>BUSINESS WORKSPACE</p>
   <a href="/dashboard">⌂ <span>Dashboard</span></a>
   <a href="/dashboard#vulnerabilities">◆ <span>Vulnerability history</span></a>
   <a href="/dashboard#scan-history">◷ <span>Past URL scans</span></a>
   <a href="/dashboard#notifications">◇ <span>Notification center</span></a>
   <a href="/dashboard#analytics">▥ <span>Analytics</span></a>
   <p>KNOWLEDGE & TOOLS</p>
   <a className={active==='learn'?'active':''} href="/learn">ⓘ <span>Security glossary</span></a>
   <a className={active==='downloads'?'active':''} href="/downloads">⇩ <span>Trusted downloads</span></a>
   <a className={active==='resolve'?'active':''} href="/resolve">✦ <span>Aegis Resolve Pro</span></a>
   <p>POLICIES</p>
   <a href="/acceptable-use">✓ <span>Authorized use</span></a>
   <a href="/terms">§ <span>Terms of service</span></a>
   <a href="/privacy">◈ <span>Privacy</span></a>
  </nav>
  <div className="portal-profile"><span>{displayName.slice(0,2).toUpperCase()}</span><div><strong>{displayName}</strong><small>{email}</small></div><button onClick={signOut}>Sign out</button></div>
 </aside>
}
