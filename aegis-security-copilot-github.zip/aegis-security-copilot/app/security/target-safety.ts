export type NormalizedTarget={hostname:string;url:string};
export type DnsResolver=(hostname:string)=>Promise<string[]>;
export type FetchLike=(input:string|URL,init?:RequestInit)=>Promise<Response>;

export class TargetSafetyError extends Error{
 code:string;httpStatus:number;
 constructor(code:string,message:string,httpStatus=400){super(message);this.name='TargetSafetyError';this.code=code;this.httpStatus=httpStatus}
}

const blockedSuffixes=['.localhost','.local','.internal','.lan','.home','.home.arpa','.test','.invalid','.example','.onion','.arpa'];
const blockedNames=new Set(['localhost','localhost.localdomain','metadata','metadata.google.internal','instance-data','instance-data.ec2.internal']);

export function normalizePublicTarget(value:string):NormalizedTarget{
 const raw=value.trim();
 if(!raw||raw.length>2048)throw new TargetSafetyError('INVALID_URL','Enter a valid public business website.');
 let parsed:URL;
 try{parsed=new URL(raw.includes('://')?raw:`https://${raw}`)}catch{throw new TargetSafetyError('INVALID_URL','Enter a valid public business website.')}
 if(parsed.protocol!=='https:'&&parsed.protocol!=='http:')throw new TargetSafetyError('UNSUPPORTED_PROTOCOL','Only HTTP and HTTPS website addresses are supported.');
 if(parsed.username||parsed.password)throw new TargetSafetyError('CREDENTIALS_NOT_ALLOWED','Website addresses must not contain usernames or passwords.');
 if(parsed.port&&parsed.port!=='80'&&parsed.port!=='443')throw new TargetSafetyError('PORT_NOT_ALLOWED','Public reviews support standard website ports only.');
 const hostname=parsed.hostname.toLowerCase().replace(/\.$/,'');
 assertPublicHostname(hostname);
 return{hostname,url:`https://${hostname}${parsed.pathname||'/'}${parsed.search}`};
}

export function assertPublicHostname(hostname:string){
 if(!hostname||hostname.length>253||blockedNames.has(hostname)||blockedSuffixes.some(suffix=>hostname.endsWith(suffix)))throw new TargetSafetyError('BLOCKED_HOST','That address is not an eligible public business hostname.');
 if(hostname.includes(':')||/^\[.*\]$/.test(hostname)||parseIpv4(hostname))throw new TargetSafetyError('IP_LITERAL_BLOCKED','Enter a public hostname rather than an IP address.');
 const labels=hostname.split('.');
 if(labels.length<2||labels.some(label=>!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label)))throw new TargetSafetyError('INVALID_HOSTNAME','Enter a valid public business hostname.');
}

export function isBlockedIp(value:string){
 const ipv4=parseIpv4(value);if(ipv4)return isBlockedIpv4(ipv4);
 const ipv6=parseIpv6(value);if(!ipv6)return true;
 if(ipv6.every(byte=>byte===0))return true;
 if(ipv6.slice(0,15).every(byte=>byte===0)&&ipv6[15]===1)return true;
 if((ipv6[0]&0xfe)===0xfc)return true;
 if(ipv6[0]===0xfe&&(ipv6[1]&0xc0)===0x80)return true;
 if(ipv6[0]===0xff)return true;
 if(ipv6[0]===0x20&&ipv6[1]===0x01&&ipv6[2]===0x0d&&ipv6[3]===0xb8)return true;
 if(ipv6.slice(0,10).every(byte=>byte===0)&&ipv6[10]===0xff&&ipv6[11]===0xff)return isBlockedIpv4(ipv6.slice(12));
 if(ipv6[0]===0&&ipv6[1]===0x64&&ipv6[2]===0xff&&ipv6[3]===0x9b)return true;
 return false;
}

export async function resolvePublicHostname(hostname:string,fetchImpl:FetchLike=fetch):Promise<string[]>{
 assertPublicHostname(hostname);
 const answers=(await Promise.allSettled([queryAddress(hostname,'A',fetchImpl),queryAddress(hostname,'AAAA',fetchImpl)])).flatMap(result=>result.status==='fulfilled'?result.value:[]);
 const unique=[...new Set(answers)];
 if(!unique.length)throw new TargetSafetyError('DNS_NOT_FOUND','The hostname did not resolve to a public web address.',422);
 const blocked=unique.find(isBlockedIp);if(blocked)throw new TargetSafetyError('BLOCKED_NETWORK','The hostname resolves to a private, reserved, or otherwise blocked network.',403);
 return unique;
}

export async function fetchPublicWebsite(startUrl:string,options:{resolver?:DnsResolver;fetchImpl?:FetchLike;timeoutMs?:number;maxRedirects?:number;method?:'HEAD'|'GET';signal?:AbortSignal;allowHttpStart?:boolean}={}){
 const resolver=options.resolver??(hostname=>resolvePublicHostname(hostname,options.fetchImpl));const fetchImpl=options.fetchImpl??fetch;const timeoutMs=options.timeoutMs??7000;const maxRedirects=options.maxRedirects??4;
 const normalizedStart=normalizePublicTarget(startUrl);let current=normalizedStart.url;if(options.allowHttpStart){const requested=new URL(startUrl.includes('://')?startUrl:`http://${startUrl}`);if(requested.protocol==='http:')current=`http://${normalizedStart.hostname}${requested.pathname||'/'}${requested.search}`}const redirects:string[]=[];
 for(let index=0;index<=maxRedirects;index++){
  const target=normalizePublicTarget(current);await resolver(target.hostname);
  let response:Response;
  try{const timeoutSignal=AbortSignal.timeout(timeoutMs);const signal=options.signal?AbortSignal.any([options.signal,timeoutSignal]):timeoutSignal;response=await fetchImpl(current,{method:options.method??'HEAD',redirect:'manual',signal,headers:{'user-agent':'Aegis-Public-Security-Review/2.0','accept':'text/html,application/xhtml+xml'}})}catch(error){
   if(options.signal?.aborted)throw new TargetSafetyError('SCAN_CANCELLED','The assessment was cancelled.',499);
   if(error instanceof DOMException&&error.name==='TimeoutError')throw new TargetSafetyError('HTTP_TIMEOUT','The website did not respond before the safety timeout.',504);
   throw new TargetSafetyError('CONNECTION_FAILED','A secure connection to the website could not be completed.',422);
  }
  if(response.status>=300&&response.status<400){
   const location=response.headers.get('location');if(!location)throw new TargetSafetyError('REDIRECT_INVALID','The website returned a redirect without a destination.',422);
   if(index===maxRedirects)throw new TargetSafetyError('REDIRECT_LIMIT','The website exceeded the safe redirect limit.',422);
   const next=new URL(location,current);normalizePublicTarget(next.toString());redirects.push(next.toString());current=next.toString();continue;
  }
  return{response,finalUrl:current,redirects};
 }
 throw new TargetSafetyError('REDIRECT_LIMIT','The website exceeded the safe redirect limit.',422);
}

async function queryAddress(hostname:string,type:'A'|'AAAA',fetchImpl:FetchLike){
 const endpoint=new URL('https://cloudflare-dns.com/dns-query');endpoint.searchParams.set('name',hostname);endpoint.searchParams.set('type',type);
 const response=await fetchImpl(endpoint,{headers:{accept:'application/dns-json'},signal:AbortSignal.timeout(5000)});if(!response.ok)throw new TargetSafetyError('DNS_PROVIDER_ERROR','The DNS safety check is temporarily unavailable.',502);
 const payload=await response.json() as {Status?:number;Answer?:Array<{type:number;data:string}>};if(payload.Status!==0&&payload.Status!==undefined)return[];
 const expected=type==='A'?1:28;return(payload.Answer??[]).filter(answer=>answer.type===expected).map(answer=>answer.data.replace(/\.$/,'')).filter(data=>type==='A'?!!parseIpv4(data):!!parseIpv6(data));
}

function parseIpv4(value:string){
 const parts=value.split('.');if(parts.length!==4||parts.some(part=>!/^\d{1,3}$/.test(part)))return null;const bytes=parts.map(Number);return bytes.every(byte=>byte>=0&&byte<=255)?bytes:null;
}
function isBlockedIpv4(bytes:number[]){
 const[a,b,c]=bytes;
 return a===0||a===10||a===127||a>=224||a===255||(a===100&&b>=64&&b<=127)||(a===169&&b===254)||(a===172&&b>=16&&b<=31)||(a===192&&b===168)||(a===192&&b===0&&c===0)||(a===192&&b===0&&c===2)||(a===198&&(b===18||b===19))||(a===198&&b===51&&c===100)||(a===203&&b===0&&c===113);
}
function parseIpv6(value:string){
 const clean=value.toLowerCase().split('%')[0];if(!clean.includes(':'))return null;
 const halves=clean.split('::');if(halves.length>2)return null;
 const parseHalf=(half:string)=>half?half.split(':').flatMap(part=>{const ipv4=parseIpv4(part);if(ipv4)return[(ipv4[0]<<8)|ipv4[1],(ipv4[2]<<8)|ipv4[3]];return/^[0-9a-f]{1,4}$/.test(part)?[Number.parseInt(part,16)]:[Number.NaN]}):[];
 const left=parseHalf(halves[0]);const right=parseHalf(halves[1]??'');if([...left,...right].some(Number.isNaN))return null;
 const missing=8-left.length-right.length;if((halves.length===1&&missing!==0)||(halves.length===2&&missing<1))return null;
 const words=[...left,...Array(Math.max(0,missing)).fill(0),...right];if(words.length!==8)return null;
 return words.flatMap(word=>[word>>8,word&255]);
}
