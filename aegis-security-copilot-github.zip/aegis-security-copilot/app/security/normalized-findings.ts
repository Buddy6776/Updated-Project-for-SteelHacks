import type { D1Database } from '@cloudflare/workers-types';
import type { AegisUser } from '../business-auth';
import { findingDefinitions } from './finding-definitions';
import type { PublicCheck } from './public-check';

type SiteScope={id:string;hostname:string};
type ExistingFinding={id:string;status:string;detectedAt:string};

export async function ensureObservedAssets(db:D1Database,userId:string,site:SiteScope,checkedAt:string){
 const definitions=[
  {type:'domain',value:site.hostname,name:site.hostname,source:'registered_domain'},
  {type:'web_application',value:`https://${site.hostname}/`,name:`Website · ${site.hostname}`,source:'passive_web_assessment'},
  {type:'public_service',value:`${site.hostname}:443/tcp`,name:'HTTPS · TCP 443',source:'passive_web_assessment'},
  {type:'certificate',value:site.hostname,name:`TLS certificate · ${site.hostname}`,source:'passive_web_assessment'},
 ];
 await db.batch(definitions.map(asset=>db.prepare("INSERT INTO assets (id,user_id,website_id,asset_type,value,display_name,source,risk_level,monitoring_enabled,first_seen_at,last_checked_at) VALUES (?,?,?,?,?,?,?,'informational',1,?,?) ON CONFLICT(user_id,asset_type,value) DO UPDATE SET website_id=excluded.website_id,display_name=excluded.display_name,source=excluded.source,monitoring_enabled=1,last_checked_at=excluded.last_checked_at").bind(crypto.randomUUID(),userId,site.id,asset.type,asset.value,asset.name,asset.source,checkedAt,checkedAt)));
 return db.prepare("SELECT id FROM assets WHERE user_id = ? AND asset_type = 'web_application' AND value = ?").bind(userId,`https://${site.hostname}/`).first<{id:string}>();
}

export async function ensurePassiveAuthorization(db:D1Database,user:AegisUser,site:SiteScope,authorizedAt:string){
 const current=await db.prepare("SELECT id FROM scan_authorizations WHERE user_id = ? AND website_id = ? AND revoked_at IS NULL AND scope = 'passive_headers' AND (expires_at IS NULL OR expires_at > ?)").bind(user.userId,site.id,authorizedAt).first<{id:string}>();
 if(current)return current.id;
 const id=crypto.randomUUID();
 await db.batch([
  db.prepare("INSERT INTO scan_authorizations (id,user_id,website_id,hostname,scope,authorized_by,authorized_at) VALUES (?,?,?,?,?,?,?)").bind(id,user.userId,site.id,site.hostname,'passive_headers',user.email,authorizedAt),
  db.prepare("INSERT INTO audit_events (id,user_id,website_id,event_type,detail,created_at) VALUES (?,?,?,?,?,?)").bind(crypto.randomUUID(),user.userId,site.id,'authorization_recorded',`Authorized passive security assessment for ${site.hostname}.`,authorizedAt),
 ]);
 return id;
}

export async function normalizePublicCheck(db:D1Database,user:AegisUser,site:SiteScope,result:PublicCheck,scanId:string,observedAt:string,actorType:'scanner'|'verification'){
 const url=`https://${site.hostname}`;const asset=await ensureObservedAssets(db,user.userId,site,observedAt);const statements=[];const observedTypes=new Set(result.findings.map(finding=>finding.type));
 for(const finding of result.findings){
  const existing=await db.prepare('SELECT id,status,detected_at AS detectedAt FROM vulnerabilities WHERE user_id = ? AND url = ? AND type = ?').bind(user.userId,url,finding.type).first<ExistingFinding>();
  if(!existing){const id=crypto.randomUUID();statements.push(db.prepare("INSERT INTO vulnerabilities (id,user_id,website_id,asset_id,url,type,category,severity,confidence,title,description,scanner,evidence,business_impact,technical_explanation,remediation,verification_guidance,cve,cwe,cvss,raw_output_reference,status,detected_at,last_seen_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'new',?,?,?)").bind(id,user.userId,site.id,asset?.id??null,url,finding.type,finding.category,finding.severity,finding.confidence,finding.title,finding.technicalExplanation,finding.scanner,finding.evidence,finding.businessImpact,finding.technicalExplanation,finding.remediation,finding.verificationGuidance,finding.cve,finding.cwe,finding.cvss,`evidence:${finding.rawEvidenceId}`,observedAt,observedAt,observedAt));statements.push(db.prepare("INSERT INTO finding_activity (id,finding_id,user_id,action,to_status,detail,actor_type,created_at) VALUES (?,?,?,'detected','new',?,?,?)").bind(crypto.randomUUID(),id,user.userId,`${finding.title} was detected by ${finding.scanner} in scan ${scanId}.`,actorType,observedAt));continue}
  const nextStatus=existing.status==='resolved'?'returned':existing.status==='new'?'open':existing.status;
  statements.push(db.prepare('UPDATE vulnerabilities SET website_id=?,asset_id=?,category=?,severity=?,confidence=?,title=?,description=?,scanner=?,evidence=?,business_impact=?,technical_explanation=?,remediation=?,verification_guidance=?,cve=?,cwe=?,cvss=?,raw_output_reference=?,status=?,last_seen_at=?,updated_at=? WHERE id=? AND user_id=?').bind(site.id,asset?.id??null,finding.category,finding.severity,finding.confidence,finding.title,finding.technicalExplanation,finding.scanner,finding.evidence,finding.businessImpact,finding.technicalExplanation,finding.remediation,finding.verificationGuidance,finding.cve,finding.cwe,finding.cvss,`evidence:${finding.rawEvidenceId}`,nextStatus,observedAt,observedAt,existing.id,user.userId));
  statements.push(db.prepare('INSERT INTO finding_activity (id,finding_id,user_id,action,from_status,to_status,detail,actor_type,created_at) VALUES (?,?,?,?,?,?,?,?,?)').bind(crypto.randomUUID(),existing.id,user.userId,nextStatus!==existing.status?(nextStatus==='returned'?'returned':'status_changed'):'observed_again',existing.status,nextStatus,nextStatus==='returned'?'A previously resolved issue was detected again.':nextStatus!==existing.status?'The finding moved from New to Existing.':`The same evidence-backed issue was observed again in scan ${scanId}.`,actorType,observedAt));
 }
 const webTypes=findingDefinitions.map(definition=>definition.type);const emailTypes=['missing_spf','dmarc_not_enforced'];const resolvable=[...(result.webEvidenceAvailable?webTypes:[]),...(result.mailConfigured===true&&result.evidence.some(item=>item.checkKey==='email'&&item.status==='observed')?emailTypes:[])];
 for(const type of resolvable){if(observedTypes.has(type))continue;const existing=await db.prepare('SELECT id,status,detected_at AS detectedAt FROM vulnerabilities WHERE user_id = ? AND url = ? AND type = ?').bind(user.userId,url,type).first<ExistingFinding>();if(!existing||existing.status==='resolved'||existing.status==='false_positive')continue;statements.push(db.prepare("UPDATE vulnerabilities SET status='resolved',last_seen_at=?,updated_at=?,raw_output_reference=? WHERE id=? AND user_id=?").bind(observedAt,observedAt,`scan:${scanId}`,existing.id,user.userId));statements.push(db.prepare("INSERT INTO finding_activity (id,finding_id,user_id,action,from_status,to_status,detail,actor_type,created_at) VALUES (?,?,?,'verified_resolved',?,'resolved',?,?,?)").bind(crypto.randomUUID(),existing.id,user.userId,existing.status,`The authorized check no longer detected this issue in scan ${scanId}.`,actorType,observedAt))}
 if(statements.length)await db.batch(statements);
 return result.findings.length;
}

export async function persistFindingSnapshot(db:D1Database,userId:string,site:SiteScope,result:PublicCheck,scanId:string,observedAt:string){const rows=await db.prepare('SELECT type,title,severity,status FROM vulnerabilities WHERE user_id=? AND website_id=?').bind(userId,site.id).all<{type:string;title:string;severity:string;status:string}>();const present=new Set(result.findings.map(finding=>finding.type));if(!rows.results.length)return;await db.batch(rows.results.map(row=>db.prepare('INSERT INTO scan_finding_snapshots (id,scan_id,user_id,website_id,finding_type,title,severity,status,present,observed_at) VALUES (?,?,?,?,?,?,?,?,?,?)').bind(crypto.randomUUID(),scanId,userId,site.id,row.type,row.title,row.severity,row.status,present.has(row.type)?1:0,observedAt)))}
